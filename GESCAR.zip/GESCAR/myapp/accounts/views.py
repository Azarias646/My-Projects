from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import AuthUser
from .forms import FormUser


def Connexion(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]

        user = authenticate(request, username = username, password = password)

        if user is not None:
            login(request, user)
            return redirect("gescar:Home")
        else:
            messages.info(request, "Informations incorrectes !")

    form = AuthenticationForm()
    return render(request, "accounts/authentification.html", {"form": form})


def Deconnexion(request):
    logout(request)
    return redirect("accounts:Connexion")


def Enregistrer(request):
    if request.method == "POST":
        form = FormUser(request.POST)

        if form.is_valid():
            form.save()
            return redirect("accounts:User_v")
    else:
        form = FormUser()
    
    return render(request, "accounts/new_user.html", {"form":form})


def User_delete(request, user_id):
    user = AuthUser.objects.get(pk = user_id)
    user.delete()
    return redirect("accounts:User_v")


def User_update(request, user_id):
    user = AuthUser.objects.get(pk = user_id)

    if request.method == "POST":
        form = FormUser(request.POST, instance = user)

        if form.is_valid():
            form.save()
            return redirect("accounts:User_v")
    else:
        form = FormUser(instance = user)
    
    return render(request, "accounts/new_user.html", {"form":form})


def User_v(request):
    users = AuthUser.objects.all().order_by("id")
    return render(request, "accounts/users.html", {"user":users})


def User_profil(request, user_id):
    cntxt = { "users": get_object_or_404(AuthUser, pk = user_id) }
    return render(request, "accounts/user_profil.html", cntxt)