from django.forms import ModelForm
from .models import AuthUser
from django import forms


class FormUser(forms.ModelForm):
    class Meta:
        model = AuthUser
        fields = ["username", "password", "email", "date_joined"]