from django.urls import path
from . import views


app_name = "accounts"


urlpatterns = [
    path('Connexion/', views.Connexion, name='Connexion'),
    path('Deconnexion/', views.Deconnexion, name='Deconnexion'),
    path('Enregistrer/', views.Enregistrer, name='Enregistrer'),
    path('User_v/', views.User_v, name="User_v"),
    path('User_profil/<int:user_id>/', views.User_profil, name="User_profil"),
    path('User_delete/<int:user_id>/', views.User_delete, name="User_delete"),
    path('User_update/<int:user_id>/', views.User_update, name="User_update"),
]