from django.urls import path
from.import views


app_name = "gescar"

urlpatterns = [
    path("", views.Home, name="Home"),
    path("Auto/", views.Auto, name="Auto"),
    path("Client_v/", views.Client_v, name="Client_v"),
    path("Client_v/<int:client_id>/", views.Profil_client, name="Profil_client"),
    path("Auto/<int:auto_id>/", views.Profil_auto, name="Profil_auto"),
    path("AjoutClient/", views.AjoutClient, name="AjoutClient"),
    path("EditClient/<int:client_id>/", views.EditClient, name="EditClient"),
    path("SupprimerClient/<int:client_id>/", views.SupprimerClient, name="SupprimerClient"),
    path("AjoutAuto/", views.AjoutAuto, name="AjoutAuto"),
    path("EditAuto/<int:auto_id>/", views.EditAuto, name="EditAuto"),
    path("SupprimerAuto/<int:auto_id>/", views.SupprimerAuto, name="SupprimerAuto"),
]