from django.shortcuts import render, get_object_or_404, redirect
#from django.http import HttpResponse
from .models import Client, Vehicule
from .forms import FormAuto, FormClient


def Home(request):
    context = {"msg": "Bienvenue"}
    return render(request, "gescar/index.html", context)


def Auto(request):
    cntxt = {"autos": Vehicule.objects.all().order_by("marque")}
    return render(request, "gescar/auto.html", cntxt)


def Profil_auto(request, auto_id):
    cntxt = { "auto": get_object_or_404(Vehicule, pk = auto_id) }
    return render(request, "gescar/auto_profil.html",cntxt)


def Client_v(request):
    cntxt = {"clients": Client.objects.all().order_by("nom")}
    return render(request, "gescar/client.html", cntxt)


def Profil_client(request, client_id):
    cntxt = { "profil": get_object_or_404(Client, pk = client_id) }
    return render(request, "gescar/client_profil.html", cntxt)


def AjoutClient(request):
    if request.method == "POST":
        form  = FormClient(request.POST)

        if form.is_valid():
            form.save()
            return redirect("gescar:Client_v")
    else:
        form = FormClient()

    return render(request, "gescar/formClient.html", {"form": form})


def SupprimerClient(request, client_id):
    profil = Client.objects.get(pk = client_id)
    profil.delete()
    return redirect("gescar/Client_v")


def EditClient(request, client_id):
    profil = Client.objects.get(pk = client_id)

    if request.method == "POST":
            form  = FormClient(request.POST, instance=profil)

            if form.is_valid():
                form.save()
                return redirect("gescar:Client_v")
    else:
        form = FormClient(instance=profil)

    return render(request, "gescar/formClient.html", {"form": form})
    

def AjoutAuto(request):
    if request.method == "POST":
        form  = FormAuto(request.POST)

        if form.is_valid():
            form.save()
            return redirect("gescar:Auto")
    else:
        form = FormAuto()

    return render(request, "gescar/formAuto.html", {"form": form})


def SupprimerAuto(request, auto_id):
    profil = Vehicule.objects.get(pk = auto_id)
    profil.delete()
    return redirect("gescar/Auto")


def EditAuto(request, auto_id):
    car = Vehicule.objects.get(pk = auto_id)

    if request.method == "POST":
            form  = FormAuto(request.POST, instance=car)

            if form.is_valid():
                form.save()
                return redirect("gescar:Auto")
    else:
        form = FormAuto(instance=car)

    return render(request, "gescar/formAuto.html", {"form": form})