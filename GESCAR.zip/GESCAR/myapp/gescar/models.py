from django.db import models


class Vehicule(models.Model):
    numero = models.AutoField(primary_key=True, auto_created=True)
    marque = models.CharField(max_length=50)
    modele = models.CharField(max_length=50)
    ETAT = [("Neuf", "Neuf"), ("Occasion", "Occasion")]
    etat = models.CharField(max_length=50, choices=ETAT)


class Client(models.Model):
    id = models.AutoField(primary_key=True, auto_created=True)
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=150)
    GENRE = [("Homme", "Homme"), ("Femme", "Femme")]
    genre = models.CharField(max_length=50, choices=GENRE)
    tel = models.CharField(max_length=60)
    mail = models.EmailField()
    date_achat = models.DateTimeField(null=True)
    numero = models.ForeignKey(Vehicule, on_delete=models.DO_NOTHING, null=True)