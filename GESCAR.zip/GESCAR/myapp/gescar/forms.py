from django.forms import ModelForm
from .models import Client, Vehicule
from django import forms


class FormClient(forms.ModelForm):
    date_achat = forms.DateField(required=False)
    numero = forms.IntegerField(required=False)
    class Meta:
        model = Client
        fields = ["nom", "prenom", "genre", "tel", "mail"]
    

class FormAuto(forms.ModelForm):
    class Meta:
        model = Vehicule
        fields = ["marque", "modele", "etat"]