-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 25 mai 2024 à 21:49
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gescar`
--

-- --------------------------------------------------------

--
-- Structure de la table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add vehicule', 7, 'add_vehicule'),
(26, 'Can change vehicule', 7, 'change_vehicule'),
(27, 'Can delete vehicule', 7, 'delete_vehicule'),
(28, 'Can view vehicule', 7, 'view_vehicule'),
(29, 'Can add client', 8, 'add_client'),
(30, 'Can change client', 8, 'change_client'),
(31, 'Can delete client', 8, 'delete_client'),
(32, 'Can view client', 8, 'view_client'),
(33, 'Can add auth group', 9, 'add_authgroup'),
(34, 'Can change auth group', 9, 'change_authgroup'),
(35, 'Can delete auth group', 9, 'delete_authgroup'),
(36, 'Can view auth group', 9, 'view_authgroup'),
(37, 'Can add auth group permissions', 10, 'add_authgrouppermissions'),
(38, 'Can change auth group permissions', 10, 'change_authgrouppermissions'),
(39, 'Can delete auth group permissions', 10, 'delete_authgrouppermissions'),
(40, 'Can view auth group permissions', 10, 'view_authgrouppermissions'),
(41, 'Can add auth permission', 11, 'add_authpermission'),
(42, 'Can change auth permission', 11, 'change_authpermission'),
(43, 'Can delete auth permission', 11, 'delete_authpermission'),
(44, 'Can view auth permission', 11, 'view_authpermission'),
(45, 'Can add auth user', 12, 'add_authuser'),
(46, 'Can change auth user', 12, 'change_authuser'),
(47, 'Can delete auth user', 12, 'delete_authuser'),
(48, 'Can view auth user', 12, 'view_authuser'),
(49, 'Can add auth user groups', 13, 'add_authusergroups'),
(50, 'Can change auth user groups', 13, 'change_authusergroups'),
(51, 'Can delete auth user groups', 13, 'delete_authusergroups'),
(52, 'Can view auth user groups', 13, 'view_authusergroups'),
(53, 'Can add auth user user permissions', 14, 'add_authuseruserpermissions'),
(54, 'Can change auth user user permissions', 14, 'change_authuseruserpermissions'),
(55, 'Can delete auth user user permissions', 14, 'delete_authuseruserpermissions'),
(56, 'Can view auth user user permissions', 14, 'view_authuseruserpermissions'),
(57, 'Can add django admin log', 15, 'add_djangoadminlog'),
(58, 'Can change django admin log', 15, 'change_djangoadminlog'),
(59, 'Can delete django admin log', 15, 'delete_djangoadminlog'),
(60, 'Can view django admin log', 15, 'view_djangoadminlog'),
(61, 'Can add django content type', 16, 'add_djangocontenttype'),
(62, 'Can change django content type', 16, 'change_djangocontenttype'),
(63, 'Can delete django content type', 16, 'delete_djangocontenttype'),
(64, 'Can view django content type', 16, 'view_djangocontenttype'),
(65, 'Can add django migrations', 17, 'add_djangomigrations'),
(66, 'Can change django migrations', 17, 'change_djangomigrations'),
(67, 'Can delete django migrations', 17, 'delete_djangomigrations'),
(68, 'Can view django migrations', 17, 'view_djangomigrations'),
(69, 'Can add django session', 18, 'add_djangosession'),
(70, 'Can change django session', 18, 'change_djangosession'),
(71, 'Can delete django session', 18, 'delete_djangosession'),
(72, 'Can view django session', 18, 'view_djangosession'),
(73, 'Can add gescar client', 19, 'add_gescarclient'),
(74, 'Can change gescar client', 19, 'change_gescarclient'),
(75, 'Can delete gescar client', 19, 'delete_gescarclient'),
(76, 'Can view gescar client', 19, 'view_gescarclient'),
(77, 'Can add gescar vehicule', 20, 'add_gescarvehicule'),
(78, 'Can change gescar vehicule', 20, 'change_gescarvehicule'),
(79, 'Can delete gescar vehicule', 20, 'delete_gescarvehicule'),
(80, 'Can view gescar vehicule', 20, 'view_gescarvehicule');

-- --------------------------------------------------------

--
-- Structure de la table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(3, 'pbkdf2_sha256$720000$NDSXobDFCN0PXhngK2EJrr$jQ8Y6jDy7qTWu76QF5XG6rNmfmW3pzGnIjEQqzhI/SE=', '2024-05-24 11:25:15.485054', 0, 'Azarias', '', '', 'azarias@gmail.com', 0, 1, '2024-05-19 12:00:42.000000'),
(5, 'pbkdf2_sha256$720000$1mu8nFK2LKFCr5qeogS1lO$tLiODiiGsejUA1Wm9R8muln40ETXVux9gAR3GRiqkyU=', '2024-05-24 11:14:21.370615', 0, 'Test', '', '', 'test@dumy.test', 0, 1, '2024-05-19 14:54:02.000000'),
(6, 'pbkdf2_sha256$720000$REfBHo8MYkwM3B1BIqLI3z$Ywb50d4N5S4ROFLu/thxQAb2o7aDCs7RnyZIqyn3IYk=', NULL, 0, 'exemple', '', '', 'exem@mail.com', 0, 1, '2024-05-19 16:00:05.000000'),
(7, 'pbkdf2_sha256$720000$jbRqZ9x9H6TUhyLuxpmzfI$UjPN4+T9ApBKCMJFfuILNC6quRIdYbNxd26p3b/zZQQ=', '2024-05-21 13:38:33.272811', 1, 'Admin_Azarias', '', '', 'lazareazriass@gmail.com', 1, 1, '2024-05-19 22:11:54.589730');

-- --------------------------------------------------------

--
-- Structure de la table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(9, 'accounts', 'authgroup'),
(10, 'accounts', 'authgrouppermissions'),
(11, 'accounts', 'authpermission'),
(12, 'accounts', 'authuser'),
(13, 'accounts', 'authusergroups'),
(14, 'accounts', 'authuseruserpermissions'),
(15, 'accounts', 'djangoadminlog'),
(16, 'accounts', 'djangocontenttype'),
(17, 'accounts', 'djangomigrations'),
(18, 'accounts', 'djangosession'),
(19, 'accounts', 'gescarclient'),
(20, 'accounts', 'gescarvehicule'),
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(8, 'gescar', 'client'),
(7, 'gescar', 'vehicule'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Structure de la table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2024-05-14 20:13:48.351227'),
(2, 'auth', '0001_initial', '2024-05-14 20:13:48.897762'),
(3, 'admin', '0001_initial', '2024-05-14 20:13:49.042433'),
(4, 'admin', '0002_logentry_remove_auto_add', '2024-05-14 20:13:49.058055'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2024-05-14 20:13:49.078793'),
(6, 'contenttypes', '0002_remove_content_type_name', '2024-05-14 20:13:49.167218'),
(7, 'auth', '0002_alter_permission_name_max_length', '2024-05-14 20:13:49.268163'),
(8, 'auth', '0003_alter_user_email_max_length', '2024-05-14 20:13:49.288324'),
(9, 'auth', '0004_alter_user_username_opts', '2024-05-14 20:13:49.297901'),
(10, 'auth', '0005_alter_user_last_login_null', '2024-05-14 20:13:49.364199'),
(11, 'auth', '0006_require_contenttypes_0002', '2024-05-14 20:13:49.364199'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2024-05-14 20:13:49.379822'),
(13, 'auth', '0008_alter_user_username_max_length', '2024-05-14 20:13:49.411840'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2024-05-14 20:13:49.430901'),
(15, 'auth', '0010_alter_group_name_max_length', '2024-05-14 20:13:49.450056'),
(16, 'auth', '0011_update_proxy_permissions', '2024-05-14 20:13:49.477533'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2024-05-14 20:13:49.482855'),
(18, 'gescar', '0001_initial', '2024-05-14 20:13:49.580131'),
(19, 'sessions', '0001_initial', '2024-05-14 20:13:49.636057'),
(20, 'gescar', '0002_alter_client_numero', '2024-05-14 21:43:08.368095'),
(21, 'gescar', '0003_alter_client_numero', '2024-05-14 21:46:16.068385'),
(22, 'gescar', '0004_alter_client_id_alter_vehicule_numero', '2024-05-14 21:50:37.542157'),
(23, 'gescar', '0005_alter_client_date_achat', '2024-05-15 11:10:19.799523'),
(24, 'gescar', '0006_client_tel', '2024-05-17 14:35:19.872804'),
(25, 'gescar', '0007_alter_client_genre_alter_vehicule_etat', '2024-05-17 21:57:12.114894'),
(26, 'gescar', '0008_alter_client_genre', '2024-05-17 23:15:14.282013'),
(27, 'gescar', '0009_alter_client_genre', '2024-05-18 11:58:50.902113'),
(28, 'gescar', '0010_alter_vehicule_etat', '2024-05-18 11:58:50.913709'),
(29, 'gescar', '0011_alter_vehicule_etat', '2024-05-18 12:36:15.341534'),
(30, 'gescar', '0012_alter_client_genre', '2024-05-18 12:37:03.623643'),
(31, 'gescar', '0013_client_image', '2024-05-18 12:42:17.175477'),
(32, 'accounts', '0001_initial', '2024-05-19 13:49:52.887188'),
(33, 'gescar', '0014_alter_client_image', '2024-05-19 13:49:52.994670'),
(34, 'gescar', '0015_remove_client_image_remove_vehicule_image', '2024-05-19 22:04:54.344397');

-- --------------------------------------------------------

--
-- Structure de la table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `gescar_client`
--

CREATE TABLE `gescar_client` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(150) NOT NULL,
  `genre` varchar(50) NOT NULL,
  `mail` varchar(254) NOT NULL,
  `date_achat` datetime(6) DEFAULT NULL,
  `numero_id` int(11) DEFAULT NULL,
  `tel` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `gescar_client`
--

INSERT INTO `gescar_client` (`id`, `nom`, `prenom`, `genre`, `mail`, `date_achat`, `numero_id`, `tel`) VALUES
(1, 'KAFANDO', 'Laurent', 'Homme', 'laur@jail.com', '2024-05-08 22:24:18.000000', NULL, '25637891'),
(2, 'ABAGA', 'Janine', 'Femme', 'janeab@gamil.com', '2024-05-25 22:24:18.000000', NULL, '22345677'),
(3, 'KABORE', 'Laura', 'Femme', 'llaure@jail.com', '2024-02-08 22:24:18.000000', NULL, '2494744'),
(4, 'TASSEMBEDO', 'Marc', 'Homme', 'marctsb@gamil.com', '2024-01-03 22:24:18.000000', NULL, '47343839'),
(5, 'LANKOANDE', 'Jake', 'Homme', 'jaquijak@jail.com', '2023-05-08 22:24:18.000000', NULL, '8778940'),
(6, 'OUEDRAOGO', 'Roxane', 'Femme', 'roroxo@gamil.com', '2022-02-25 22:24:18.000000', NULL, '000098'),
(7, 'SAWADOGO', 'Rolande', 'Femme', 'test@ex.exe', NULL, NULL, '1027211'),
(10, 'BAFANA', 'Roger', 'Homme', 'bafrog@email.com', NULL, NULL, '12345678'),
(11, 'DANGOTE', 'Romuald', 'Homme', 'romu@mail.co', NULL, NULL, '09738212');

-- --------------------------------------------------------

--
-- Structure de la table `gescar_vehicule`
--

CREATE TABLE `gescar_vehicule` (
  `numero` int(11) NOT NULL,
  `marque` varchar(50) NOT NULL,
  `modele` varchar(50) NOT NULL,
  `etat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `gescar_vehicule`
--

INSERT INTO `gescar_vehicule` (`numero`, `marque`, `modele`, `etat`) VALUES
(1, 'Toyota', 'Rav-4', 'Occasion'),
(2, 'Suzuki', 'Vitara', 'occasion'),
(3, 'Mercedes', 'AMG 63', 'Occasion'),
(4, 'Toyota', '4 runner', 'Occasion'),
(5, 'Hyundai', 'Elantra', 'Occasion'),
(6, 'Kia', 'Sportage', 'Neuf'),
(7, 'Lamborghini', 'Aventador', 'Neuf'),
(8, 'Bugatti', 'Chiron', 'Neuf'),
(9, 'Audi', 'Q3', 'Neuf'),
(10, 'Opel', 'Corsa', 'Neuf'),
(11, 'Porsche', 'Panamera', 'Occasion');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Index pour la table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Index pour la table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Index pour la table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Index pour la table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Index pour la table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Index pour la table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Index pour la table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Index pour la table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Index pour la table `gescar_client`
--
ALTER TABLE `gescar_client`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gescar_client_numero_id_a30a68ff_fk_gescar_vehicule_numero` (`numero_id`);

--
-- Index pour la table `gescar_vehicule`
--
ALTER TABLE `gescar_vehicule`
  ADD PRIMARY KEY (`numero`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT pour la table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT pour la table `gescar_client`
--
ALTER TABLE `gescar_client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `gescar_vehicule`
--
ALTER TABLE `gescar_vehicule`
  MODIFY `numero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Contraintes pour la table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Contraintes pour la table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Contraintes pour la table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Contraintes pour la table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Contraintes pour la table `gescar_client`
--
ALTER TABLE `gescar_client`
  ADD CONSTRAINT `gescar_client_numero_id_a30a68ff_fk_gescar_vehicule_numero` FOREIGN KEY (`numero_id`) REFERENCES `gescar_vehicule` (`numero`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
